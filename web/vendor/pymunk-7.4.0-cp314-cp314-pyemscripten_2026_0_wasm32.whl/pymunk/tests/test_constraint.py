import copy
import gc
import pickle
import unittest

import pymunk as p
from pymunk.constraints import *


class UnitTestConstraint(unittest.TestCase):
    def test_a(self) -> None:
        a, b = p.Body(10, 10), p.Body(10, 10)
        j = PivotJoint(a, b, (0, 0))
        self.assertEqual(j.a, a)

    def test_b(self) -> None:
        a, b = p.Body(10, 10), p.Body(10, 10)
        j = PivotJoint(a, b, (0, 0))
        self.assertEqual(j.b, b)

    def test_max_force(self) -> None:
        a, b = p.Body(10, 10), p.Body(10, 10)
        j = PivotJoint(a, b, (0, 0))
        self.assertEqual(j.max_force, float("inf"))
        j.max_force = 10
        self.assertEqual(j.max_force, 10)

    def test_error_bias(self) -> None:
        a, b = p.Body(10, 10), p.Body(10, 10)
        j = PivotJoint(a, b, (0, 0))
        self.assertAlmostEqual(j.error_bias, pow(1.0 - 0.1, 60.0))
        j.error_bias = 0.3
        self.assertEqual(j.error_bias, 0.3)

    def test_max_bias(self) -> None:
        a, b = p.Body(10, 10), p.Body(10, 10)
        j = PivotJoint(a, b, (0, 0))
        self.assertEqual(j.max_bias, float("inf"))
        j.max_bias = 10
        self.assertEqual(j.max_bias, 10)

    def test_collide_bodies(self) -> None:
        a, b = p.Body(10, 10), p.Body(10, 10)
        j = PivotJoint(a, b, (0, 0))
        self.assertEqual(j.collide_bodies, True)
        j.collide_bodies = False
        self.assertEqual(j.collide_bodies, False)

    def test_impulse(self) -> None:
        a, b = p.Body(10, 10), p.Body(10, 10)
        b.position = 0, 10
        j = PivotJoint(a, b, (0, 0))

        s = p.Space()
        s.gravity = 0, 10
        s.add(b, j)
        self.assertEqual(j.impulse, 0)
        s.step(1)
        self.assertAlmostEqual(j.impulse, 50)

    def test_activate(self) -> None:
        a, b = p.Body(4, 5), p.Body(10, 10)
        j = PivotJoint(a, b, (0, 0))
        s = p.Space()
        s.sleep_time_threshold = 0.01
        s.add(a, b)
        a.sleep()
        b.sleep()

        j.activate_bodies()
        self.assertFalse(a.is_sleeping)
        self.assertFalse(b.is_sleeping)

    def test_pre_solve(self) -> None:
        b = p.Body(1, 2)
        s = p.Space()
        j = PivotJoint(s.static_body, b, (0, 0))

        s.add(b, j)
        self.assertIsNone(j.pre_solve)
        s.step(1)

        actual_constraint = None
        actual_space = None

        def pre_solve(constraint: Constraint, space: p.Space) -> None:
            nonlocal actual_constraint
            nonlocal actual_space
            actual_constraint = constraint
            actual_space = space

        j.pre_solve = pre_solve
        s.step(1)

        self.assertEqual(actual_constraint, j)
        self.assertEqual(actual_space, s)

    def test_post_solve(self) -> None:
        b = p.Body(1, 2)
        s = p.Space()
        j = PivotJoint(s.static_body, b, (0, 0))

        s.add(b, j)
        self.assertIsNone(j.pre_solve)
        s.step(1)

        actual_constraint = None
        actual_space = None

        def post_solve(constraint: Constraint, space: p.Space) -> None:
            nonlocal actual_constraint
            nonlocal actual_space
            actual_constraint = constraint
            actual_space = space

        j.post_solve = post_solve
        s.step(1)

        self.assertEqual(actual_constraint, j)
        self.assertEqual(actual_space, s)

    def test_pre_post_solve_order(self) -> None:
        s = p.Space()
        b = p.Body(1, 2)
        j = PivotJoint(s.static_body, b, (0, 0))

        s.add(b, j)

        actual_order = []

        def pre_solve(c: Constraint, s: p.Space) -> None:
            nonlocal actual_order
            actual_order.append(1)

        def post_solve(c: Constraint, s: p.Space) -> None:
            nonlocal actual_order
            actual_order.append(2)

        j.pre_solve = pre_solve
        j.post_solve = post_solve
        s.step(1)

        self.assertEqual(actual_order, [1, 2])

    def test_pickle(self) -> None:
        a, b = p.Body(4, 5), p.Body(10, 10)
        a.custom = "a"
        b.custom = "b"
        j = PivotJoint(a, b, (1, 2))
        j.custom = "test"
        j.max_force = 2
        j.error_bias = 3
        j.max_bias = 4
        j.collide_bodies = False

        j.pre_solve = pre_solve

        j.post_solve = post_solve

        s = pickle.dumps(j)
        j2 = pickle.loads(s)
        self.assertEqual(j.custom, j2.custom)
        self.assertEqual(j.max_force, j2.max_force)
        self.assertEqual(j.error_bias, j2.error_bias)
        self.assertEqual(j.max_bias, j2.max_bias)
        self.assertEqual(j.collide_bodies, j2.collide_bodies)
        self.assertEqual(j.a.custom, j2.a.custom)
        self.assertEqual(j.b.custom, j2.b.custom)

        self.assertEqual(j.pre_solve, j2.pre_solve)
        self.assertEqual(j.post_solve, j2.post_solve)

        j2 = j.copy()

    def test_body_types(self) -> None:
        supported = [
            (p.Body.DYNAMIC, p.Body.DYNAMIC),
            (p.Body.DYNAMIC, p.Body.KINEMATIC),
            (p.Body.DYNAMIC, p.Body.STATIC),
            (p.Body.KINEMATIC, p.Body.DYNAMIC),
            (p.Body.STATIC, p.Body.DYNAMIC),
        ]
        non_supported = [
            (p.Body.KINEMATIC, p.Body.KINEMATIC),
            (p.Body.KINEMATIC, p.Body.STATIC),
            (p.Body.STATIC, p.Body.KINEMATIC),
            (p.Body.STATIC, p.Body.STATIC),
        ]

        for type1, type2 in supported:
            a, b = p.Body(4, 5, body_type=type1), p.Body(10, 10, body_type=type2)
            _ = PivotJoint(a, b, (1, 2))

            for type3, type4 in non_supported:
                with self.assertRaises(AssertionError):
                    a.body_type = type3
                    a.body_type = type4

        for type1, type2 in non_supported:
            a, b = p.Body(4, 5, body_type=type1), p.Body(10, 10, body_type=type2)
            with self.assertRaises(AssertionError):
                _ = PivotJoint(a, b, (1, 2))

    def test_delete(self) -> None:
        a, b = p.Body(1), p.Body(2)
        j1 = PivotJoint(a, b, (0, 0))
        j2 = PivotJoint(a, b, (0, 0))

        del j1
        gc.collect()

        self.assertListEqual(list(a.constraints), [j2])
        self.assertListEqual(list(b.constraints), [j2])


class UnitTestPinJoint(unittest.TestCase):
    def test_anchor(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = PinJoint(a, b, (1, 2), (3, 4))
        self.assertEqual(j.anchor_a, (1, 2))
        self.assertEqual(j.anchor_b, (3, 4))
        j.anchor_a = (5, 6)
        j.anchor_b = (7, 8)
        self.assertEqual(j.anchor_a, (5, 6))
        self.assertEqual(j.anchor_b, (7, 8))

    def test_distane(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = PinJoint(a, b, (0, 0), (10, 0))
        self.assertEqual(j.distance, 10)
        j.distance = 20
        self.assertEqual(j.distance, 20)

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = PinJoint(a, b, (1, 2), (3, 4))
        j.distance = 8

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.anchor_a, j2.anchor_a)
        self.assertEqual(j.anchor_b, j2.anchor_b)
        self.assertEqual(j.distance, j2.distance)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)

    def test_copy_distance(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        b.position = (3, 4)
        j = PinJoint(a, b)
        j.distance = 8
        for clone in (j.copy, lambda: copy.deepcopy(j)):
            with self.subTest(clone=clone):
                j2 = clone()
                self.assertEqual(j2.distance, 8)
                self.assertIsNot(j2.a, a)
                self.assertIsNot(j2.b, b)


class UnitTestSlideJoint(unittest.TestCase):
    def test_anchor(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = SlideJoint(a, b, (1, 2), (3, 4), 0, 10)
        self.assertEqual(j.anchor_a, (1, 2))
        self.assertEqual(j.anchor_b, (3, 4))
        j.anchor_a = (5, 6)
        j.anchor_b = (7, 8)
        self.assertEqual(j.anchor_a, (5, 6))
        self.assertEqual(j.anchor_b, (7, 8))

    def test_min(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = SlideJoint(a, b, (0, 0), (0, 0), 1, 0)
        self.assertEqual(j.min, 1)
        j.min = 2
        self.assertEqual(j.min, 2)

    def test_max(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = SlideJoint(a, b, (0, 0), (0, 0), 0, 1)
        self.assertEqual(j.max, 1)
        j.max = 2
        self.assertEqual(j.max, 2)

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = SlideJoint(a, b, (1, 2), (3, 4), 5, 6)

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.anchor_a, j2.anchor_a)
        self.assertEqual(j.anchor_b, j2.anchor_b)
        self.assertEqual(j.min, j2.min)
        self.assertEqual(j.max, j2.max)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)


class UnitTestPivotJoint(unittest.TestCase):
    def test_anchor_by_pivot(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        a.position = (5, 7)
        j = PivotJoint(a, b, (1, 2))
        self.assertEqual(j.anchor_a, (-4, -5))
        self.assertEqual(j.anchor_b, (1, 2))

    def test_anchor_by_anchor(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = PivotJoint(a, b, (1, 2), (3, 4))
        self.assertEqual(j.anchor_a, (1, 2))
        self.assertEqual(j.anchor_b, (3, 4))
        j.anchor_a = (5, 6)
        j.anchor_b = (7, 8)
        self.assertEqual(j.anchor_a, (5, 6))
        self.assertEqual(j.anchor_b, (7, 8))

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = PivotJoint(a, b, (1, 2), (3, 4))

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.anchor_a, j2.anchor_a)
        self.assertEqual(j.anchor_b, j2.anchor_b)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)


class UnitTestGrooveJoint(unittest.TestCase):
    def test_anchor(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = GrooveJoint(a, b, (0, 0), (0, 0), (1, 2))
        self.assertEqual(j.anchor_b, (1, 2))
        j.anchor_b = (3, 4)
        self.assertEqual(j.anchor_b, (3, 4))

    def test_groove(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = GrooveJoint(a, b, (1, 2), (3, 4), (0, 0))
        self.assertEqual(j.groove_a, (1, 2))
        self.assertEqual(j.groove_b, (3, 4))
        j.groove_a = (5, 6)
        j.groove_b = (7, 8)
        self.assertEqual(j.groove_a, (5, 6))
        self.assertEqual(j.groove_b, (7, 8))

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = GrooveJoint(a, b, (1, 2), (3, 4), (5, 6))

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.groove_a, j2.groove_a)
        self.assertEqual(j.groove_b, j2.groove_b)
        self.assertEqual(j.anchor_b, j2.anchor_b)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)


class UnitTestDampedSpring(unittest.TestCase):
    def test_anchor(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedSpring(a, b, (1, 2), (3, 4), 0, 0, 0)
        self.assertEqual(j.anchor_a, (1, 2))
        self.assertEqual(j.anchor_b, (3, 4))
        j.anchor_a = (5, 6)
        j.anchor_b = (7, 8)
        self.assertEqual(j.anchor_a, (5, 6))
        self.assertEqual(j.anchor_b, (7, 8))

    def test_rest_length(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedSpring(a, b, (0, 0), (0, 0), 1, 0, 0)
        self.assertEqual(j.rest_length, 1)
        j.rest_length = 2
        self.assertEqual(j.rest_length, 2)

    def test_stiffness(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedSpring(a, b, (0, 0), (0, 0), 0, 1, 0)
        self.assertEqual(j.stiffness, 1)
        j.stiffness = 2
        self.assertEqual(j.stiffness, 2)

    def test_damping(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedSpring(a, b, (0, 0), (0, 0), 0, 0, 1)
        self.assertEqual(j.damping, 1)
        j.damping = 2
        self.assertEqual(j.damping, 2)

    def test_force_func(self) -> None:
        s = p.Space()
        a, b = p.Body(10, 10), p.Body(20, 20)
        b.position = 0, 100
        j = DampedSpring(a, b, (0, 0), (0, 0), 0, 1, 0)
        s.add(a, b, j)

        def f(spring: p.DampedSpring, dist: float) -> float:
            self.assertEqual(spring, j)
            self.assertEqual(dist, 100)

            return 1

        self.assertEqual(j.force_func, DampedSpring.spring_force)

        j.force_func = f
        self.assertEqual(f, j.force_func)
        s.step(1)
        self.assertEqual(j.impulse, 1)

        j.force_func = DampedSpring.spring_force
        s.step(1)
        self.assertAlmostEqual(j.impulse, -100.15)

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedSpring(a, b, (1, 2), (3, 4), 5, 6, 7)

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.anchor_a, j2.anchor_a)
        self.assertEqual(j.anchor_b, j2.anchor_b)
        self.assertEqual(j.rest_length, j2.rest_length)
        self.assertEqual(j.stiffness, j2.stiffness)
        self.assertEqual(j.damping, j2.damping)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)

    def test_copy_force_func(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        b.position = (3, 0)
        j = DampedSpring(a, b, (0, 0), (0, 0), 1, 2, 0)
        j.force_func = nonlinear_spring_force
        for clone in (
            j.copy,
            lambda: copy.deepcopy(j),
            lambda: pickle.loads(pickle.dumps(j)),
        ):
            with self.subTest(clone=clone):
                j2 = clone()
                self.assertIs(j2.force_func, nonlinear_spring_force)
                space = p.Space()
                space.add(j2.a, j2.b, j2)
                space.step(0.125)
                self.assertEqual(j2.impulse, -2)

        j.force_func = DampedSpring.spring_force
        j2 = pickle.loads(pickle.dumps(j))
        self.assertIs(j2.force_func, DampedSpring.spring_force)
        space = p.Space()
        space.add(j2.a, j2.b, j2)
        space.step(0.125)
        self.assertEqual(j2.impulse, -0.5)


class UnitTestDampedRotarySpring(unittest.TestCase):
    def test_rest_angle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedRotarySpring(a, b, 1, 0, 0)
        self.assertEqual(j.rest_angle, 1)
        j.rest_angle = 2
        self.assertEqual(j.rest_angle, 2)

    def test_stiffness(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedRotarySpring(a, b, 0, 1, 0)
        self.assertEqual(j.stiffness, 1)
        j.stiffness = 2
        self.assertEqual(j.stiffness, 2)

    def test_damping(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedRotarySpring(a, b, 0, 0, 1)
        self.assertEqual(j.damping, 1)
        j.damping = 2
        self.assertEqual(j.damping, 2)

    def test_torque_func(self) -> None:
        s = p.Space()
        a, b = p.Body(10, 10), p.Body(20, 20)
        b.angle = 2
        j = DampedRotarySpring(a, b, 0, 10, 0)
        s.add(a, b, j)

        def f(spring: p.DampedRotarySpring, relative_angle: float) -> float:
            self.assertEqual(spring, j)
            self.assertEqual(relative_angle, -2)

            return 1

        self.assertEqual(j.torque_func, DampedRotarySpring.spring_torque)

        j.torque_func = f
        self.assertEqual(f, j.torque_func)
        s.step(1)
        self.assertEqual(j.impulse, 1)

        j.torque_func = DampedRotarySpring.spring_torque
        s.step(1)
        self.assertAlmostEqual(j.impulse, -21.5)

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = DampedRotarySpring(a, b, 1, 2, 3)

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.rest_angle, j2.rest_angle)
        self.assertEqual(j.stiffness, j2.stiffness)
        self.assertEqual(j.damping, j2.damping)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)

    def test_copy_torque_func(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        b.angle = 2
        j = DampedRotarySpring(a, b, 0, 2, 0)
        j.torque_func = nonlinear_spring_torque
        for clone in (
            j.copy,
            lambda: copy.deepcopy(j),
            lambda: pickle.loads(pickle.dumps(j)),
        ):
            with self.subTest(clone=clone):
                j2 = clone()
                self.assertIs(j2.torque_func, nonlinear_spring_torque)
                space = p.Space()
                space.add(j2.a, j2.b, j2)
                space.step(0.125)
                self.assertEqual(j2.impulse, -2)

        j.torque_func = DampedRotarySpring.spring_torque
        j2 = pickle.loads(pickle.dumps(j))
        self.assertIs(j2.torque_func, DampedRotarySpring.spring_torque)
        space = p.Space()
        space.add(j2.a, j2.b, j2)
        space.step(0.125)
        self.assertEqual(j2.impulse, -0.5)


class UnitTestRotaryLimitJoint(unittest.TestCase):
    def test_min(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = RotaryLimitJoint(a, b, 1, 0)
        self.assertEqual(j.min, 1)
        j.min = 2
        self.assertEqual(j.min, 2)

    def test_max(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = RotaryLimitJoint(a, b, 0, 1)
        self.assertEqual(j.max, 1)
        j.max = 2
        self.assertEqual(j.max, 2)

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = RotaryLimitJoint(a, b, 1, 2)

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.min, j2.min)
        self.assertEqual(j.max, j2.max)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)


class UnitTestRatchetJoint(unittest.TestCase):
    def test_angle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = RatchetJoint(a, b, 0, 0)
        self.assertEqual(j.angle, 0)
        j.angle = 1
        self.assertEqual(j.angle, 1)

    def test_phase(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = RatchetJoint(a, b, 1, 0)
        self.assertEqual(j.phase, 1)
        j.phase = 2
        self.assertEqual(j.phase, 2)

    def test_ratchet(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = RatchetJoint(a, b, 0, 1)
        self.assertEqual(j.ratchet, 1)
        j.ratchet = 2
        self.assertEqual(j.ratchet, 2)

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = RatchetJoint(a, b, 1, 2)
        j.angle = 3

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.angle, j2.angle)
        self.assertEqual(j.phase, j2.phase)
        self.assertEqual(j.ratchet, j2.ratchet)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)

    def test_copy_angle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        b.angle = 0.25
        j = RatchetJoint(a, b, 0, 0.5)
        j.angle = 1.5
        for clone in (j.copy, lambda: copy.deepcopy(j)):
            with self.subTest(clone=clone):
                j2 = clone()
                self.assertEqual(j2.angle, 1.5)
                self.assertIsNot(j2.a, a)
                self.assertIsNot(j2.b, b)


class UnitTestGearJoint(unittest.TestCase):
    def test_phase(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = GearJoint(a, b, 1, 0)
        self.assertEqual(j.phase, 1)
        j.phase = 2
        self.assertEqual(j.phase, 2)

    def test_ratio(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = GearJoint(a, b, 0, 1)
        self.assertEqual(j.ratio, 1)
        j.ratio = 2
        self.assertEqual(j.ratio, 2)

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = GearJoint(a, b, 1, 2)

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.phase, j2.phase)
        self.assertEqual(j.ratio, j2.ratio)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)


class UnitTestSimleMotor(unittest.TestCase):
    def test_simple_motor(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = SimpleMotor(a, b, 0.3)
        self.assertEqual(j.rate, 0.3)
        j.rate = 0.4
        self.assertEqual(j.rate, 0.4)

    def test_pickle(self) -> None:
        a, b = p.Body(10, 10), p.Body(20, 20)
        j = SimpleMotor(a, b, 1)

        s = pickle.dumps(j)
        j2 = pickle.loads(s)

        self.assertEqual(j.rate, j2.rate)
        self.assertEqual(j.a.mass, j2.a.mass)
        self.assertEqual(j.b.mass, j2.b.mass)


# Needed to be able to pickle
def pre_solve(c: Constraint, s: p.Space) -> None:
    pass


def post_solve(c: Constraint, s: p.Space) -> None:
    pass


def nonlinear_spring_force(spring: DampedSpring, distance: float) -> float:
    return spring.stiffness * (spring.rest_length - distance) ** 3


def nonlinear_spring_torque(spring: DampedRotarySpring, relative_angle: float) -> float:
    return spring.stiffness * (relative_angle - spring.rest_angle) ** 3
